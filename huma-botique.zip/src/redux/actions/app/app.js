import * as appActions from "./appActions";
export default appActions;